
FocusCombo — Web (PWA) Deploy Kit
=================================
- Plans: ₹599 / ₹2999 / ₹5999
- WhatsApp: 9304252286
- Email: sayeedammaar42@gmail.com
- UPI: a.sayeed@ptaxis

Deploy (Firebase):
1) npm i -g firebase-tools
2) firebase login
3) firebase projects:create (or use console)
4) firebase use --add
5) firebase deploy

Netlify/Vercel: publish 'public' folder.
